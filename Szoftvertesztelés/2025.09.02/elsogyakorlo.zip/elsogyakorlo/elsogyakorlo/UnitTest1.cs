namespace elsogyakorlo
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            
        }

        class Calcurator
        {
            public Calcurator() { }

            public int Osszeg(int a, int b)
            {
                return a + b;
            }

            public int Kivonas(int a, int b)
            {
                return a - b;
            }

            public int Szorzas(int a, int b)
            {
                return a * b;
            }
            public int Osztas(int a, int b)
            {
                if (b == 0)
                {
                    throw new DivideByZeroException();
                    

                }
                else
                {
                    return a / b;
                }
            }
        }
        

        [Test]
        public void Test1()
        {
            int c = 1;
            int d = 2;
            Calcurator x = new Calcurator();

            Assert.AreEqual(x.Osszeg(c, d), c + d);
        }

        [Test]
        public void Test2()
        {
            int c = 1;
            int d = 2;
            Calcurator x = new Calcurator();

            Assert.AreEqual(x.Kivonas(c, d), c - d);
        }

        [Test]
        public void Test3()
        {
            int c = 1;
            int d = 2;
            Calcurator x = new Calcurator();

            Assert.AreEqual(x.Szorzas(c, d), c * d);
        }

        [Test]
        public void Test4()
        {
            int c = 1;
            int d = 2;
            Calcurator x = new Calcurator();

            Assert.AreEqual(x.Osztas(c, d), c / d);
        }

        [Test]
        public void Test5()
        {
            int c = 1;
            int d = 0;
            Calcurator x = new Calcurator();
             Assert.Throws<DivideByZeroException> (() => x.Osztas (c, d));
            
        }
    }
}